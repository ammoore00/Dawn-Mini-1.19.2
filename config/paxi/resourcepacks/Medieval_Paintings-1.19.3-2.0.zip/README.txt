For the best experience, consider downloading this mod aswell -
https://www.curseforge.com/minecraft/mc-mods/medieval-paintings